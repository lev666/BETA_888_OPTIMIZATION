### snapdragon_888_optimization v3.4 beta - 02.11.2022

* General / EN
  * I have returned the Russian language
  * Added automatic installation
  * Corrected the text
  * Removed unnecessary items
* General / RU
  * Вернул русский язык
  * Добавил автоматическую установку
  * Подкорректировал текст
  * Убрал лишние пункты