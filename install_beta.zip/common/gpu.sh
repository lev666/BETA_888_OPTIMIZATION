

chmod 644 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo 608000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
chmod 644 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
echo 150 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
chmod 644 /sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/kgsl/kgsl-3d0/max_pwrlevel
echo 4 > /sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/kgsl/kgsl-3d0/max_pwrlevel