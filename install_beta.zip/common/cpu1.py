#!/data/adb/888/dtb/bin/python3

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage-level = <0x180>;', 'qcom,init-voltage-level = <0x160>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x124f80>;', 'qcom,init-voltage = <0x118c30>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x132a40>;', 'qcom,init-voltage = <0x1312d0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0xffdc0>;', 'qcom,init-voltage = <0x132a40>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x1b7740>;', 'qcom,init-voltage = <0x1b1980>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data) 

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x1b9680>;', 'qcom,init-voltage = <0x1b7740>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)                         

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0xd0020>;', 'qcom,init-voltage = <0xc3500>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0xdcb40>;', 'qcom,init-voltage = <0xd0020>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)  

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0xdea80>;', 'qcom,init-voltage = <0xdcb40>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)   

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0xe86c0>;', 'qcom,init-voltage = <0xdea80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)   

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x2d2a80>;', 'qcom,init-voltage = <0x2ab980>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x2dc6c0>;', 'qcom,init-voltage = <0x2d2a80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)  

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x2ee000>;', 'qcom,init-voltage = <0x2dc6c0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)   

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0xd6d80>;', 'qcom,init-voltage = <0xc3500>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)   

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x263540>;', 'qcom,init-voltage = <0x2191c0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x1cafc0>;', 'qcom,init-voltage = <0x1b1980>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x2de600>;', 'qcom,init-voltage = <0x2dc6c0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
