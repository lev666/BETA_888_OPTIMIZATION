#!/data/adb/888/dtb/bin/python3



with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,initial-pwrlevel = <0x09>;', 'qcom,initial-pwrlevel = <0x0a>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,initial-pwrlevel = <0x9>;', 'qcom,initial-pwrlevel = <0xa>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom0 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@0 {\n\t\t\t\t\t\treg = <0x0>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x32116200>;\n\t\t\t\t\t\tqcom,level = <0x1a0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0x882a5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@0 {\n\t\t\t\t\t\treg = <0x0>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x32a9f880>;\n\t\t\t\t\t\tqcom,level = <0x1a0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0x882a5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom0 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@0 {\n\t\t\t\t\t\treg = <0x00>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x32116200>;\n\t\t\t\t\t\tqcom,level = <0x1a0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0x882a5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@0 {\n\t\t\t\t\t\treg = <0x00>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x32a9f880>;\n\t\t\t\t\t\tqcom,level = <0x1a0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0x882a5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom1 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@1 {\n\t\t\t\t\t\treg = <0x1>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x2e5f5680>;\n\t\t\t\t\t\tqcom,level = <0x180>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82a5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@1 {\n\t\t\t\t\t\treg = <0x1>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x30e03500>;\n\t\t\t\t\t\tqcom,level = <0x180>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82a5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom1 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@1 {\n\t\t\t\t\t\treg = <0x01>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x2e5f5680>;\n\t\t\t\t\t\tqcom,level = <0x180>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82a5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@1 {\n\t\t\t\t\t\treg = <0x01>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x30e03500>;\n\t\t\t\t\t\tqcom,level = <0x180>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82a5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom2 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@2 {\n\t\t\t\t\t\treg = <0x2>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x2bfcfc80>;\n\t\t\t\t\t\tqcom,level = <0x140>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82a5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@2 {\n\t\t\t\t\t\treg = <0x2>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x2e5f5680>;\n\t\t\t\t\t\tqcom,level = <0x100>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82a5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom2 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@2 {\n\t\t\t\t\t\treg = <0x02>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x2bfcfc80>;\n\t\t\t\t\t\tqcom,level = <0x140>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82a5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@2 {\n\t\t\t\t\t\treg = <0x02>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x2e5f5680>;\n\t\t\t\t\t\tqcom,level = <0x100>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82a5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom3 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@3 {\n\t\t\t\t\t\treg = <0x3>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x284af100>;\n\t\t\t\t\t\tqcom,level = <0x100>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0xa>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0xa>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0x882b5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@3 {\n\t\t\t\t\t\treg = <0x3>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x2bfcfc80>;\n\t\t\t\t\t\tqcom,level = <0xe0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0xa>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0xa>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0x882b5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom3 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@3 {\n\t\t\t\t\t\treg = <0x03>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x284af100>;\n\t\t\t\t\t\tqcom,level = <0x100>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0x882b5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@3 {\n\t\t\t\t\t\treg = <0x03>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x2bfcfc80>;\n\t\t\t\t\t\tqcom,level = <0xe0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0x882b5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom4 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@4 {\n\t\t\t\t\t\treg = <0x4>;\n\t\t\t\t\t\tqcom,gpu-freq = "$=X";\n\t\t\t\t\t\tqcom,level = <0xe0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x7>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82b5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@4 {\n\t\t\t\t\t\treg = <0x4>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x284af100>;\n\t\t\t\t\t\tqcom,level = <0xc0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x7>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xb>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0xb>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82b5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom4 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@4 {\n\t\t\t\t\t\treg = <0x04>;\n\t\t\t\t\t\tqcom,gpu-freq = "$=X";\n\t\t\t\t\t\tqcom,level = <0xe0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x07>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82b5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@4 {\n\t\t\t\t\t\treg = <0x04>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x284af100>;\n\t\t\t\t\t\tqcom,level = <0xc0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x07>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0b>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x0b>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82b5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom5 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@5 {\n\t\t\t\t\t\treg = <0x5>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x202fbf00>;\n\t\t\t\t\t\tqcom,level = <0xc0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x7>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xa>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x9>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82c5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@5 {\n\t\t\t\t\t\treg = <0x5>;\n\t\t\t\t\t\tqcom,gpu-freq = "$=X";\n\t\t\t\t\t\tqcom,level = <0x90>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x7>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xa>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x9>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82c5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom5 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@5 {\n\t\t\t\t\t\treg = <0x05>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x202fbf00>;\n\t\t\t\t\t\tqcom,level = <0xc0>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x07>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x09>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82c5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@5 {\n\t\t\t\t\t\treg = <0x05>;\n\t\t\t\t\t\tqcom,gpu-freq = "$=X";\n\t\t\t\t\t\tqcom,level = <0x90>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x07>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x09>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82c5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom6 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@6 {\n\t\t\t\t\t\treg = <0x6>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x1d4410c0>;\n\t\t\t\t\t\tqcom,level = <0x90>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x6>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xa>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x5>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82c5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@6 {\n\t\t\t\t\t\treg = <0x6>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x202fbf00>;\n\t\t\t\t\t\tqcom,level = <0x80>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x6>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xa>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x5>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82c5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom6 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@6 {\n\t\t\t\t\t\treg = <0x06>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x1d4410c0>;\n\t\t\t\t\t\tqcom,level = <0x90>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x06>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x05>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82c5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@6 {\n\t\t\t\t\t\treg = <0x06>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x202fbf00>;\n\t\t\t\t\t\tqcom,level = <0x80>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x06>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x05>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82c5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom7 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@7 {\n\t\t\t\t\t\treg = <0x7>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x1a67a4c0>;\n\t\t\t\t\t\tqcom,level = <0x80>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x6>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xa>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x5>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82d5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@7 {\n\t\t\t\t\t\treg = <0x7>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x1a67a4c0>;\n\t\t\t\t\t\tqcom,level = <0x60>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x6>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xa>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x5>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82d5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom7 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@7 {\n\t\t\t\t\t\treg = <0x07>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x1a67a4c0>;\n\t\t\t\t\t\tqcom,level = <0x80>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x06>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x05>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82d5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@7 {\n\t\t\t\t\t\treg = <0x07>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x1a67a4c0>;\n\t\t\t\t\t\tqcom,level = <0x60>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x06>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x05>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0xa82d5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom8 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@8 {\n\t\t\t\t\t\treg = <0x8>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x169714c0>;\n\t\t\t\t\t\tqcom,level = <0x50>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x6>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xa>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x6>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x5>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0x882e5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@8 {\n\t\t\t\t\t\treg = <0x8>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x169714c0>;\n\t\t\t\t\t\tqcom,level = <0x50>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x8>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x6>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0xa>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x6>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x5>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0x882e5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom8 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@8 {\n\t\t\t\t\t\treg = <0x08>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x169714c0>;\n\t\t\t\t\t\tqcom,level = <0x50>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x06>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x06>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x05>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0x882e5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@8 {\n\t\t\t\t\t\treg = <0x08>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x169714c0>;\n\t\t\t\t\t\tqcom,level = <0x50>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x08>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x06>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x0a>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x06>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x05>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0x882e5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



#qcom9, 10 - new

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@9 {\n\t\t\t\t\t\treg = <0x9>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x12c684c0>;\n\t\t\t\t\t\tqcom,level = <0x40>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x2>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x2>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x9>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x2>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x2>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0x882f5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@9 {\n\t\t\t\t\t\treg = <0x9>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x12c684c0>;\n\t\t\t\t\t\tqcom,level = <0x40>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x2>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x2>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x9>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x2>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x2>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0x882f5ffd>;\n\t\t\t\t\t};\n\n\t\t\t\t\tqcom,gpu-pwrlevel@10 {\n\t\t\t\t\t\treg = <0xa>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x8f0d180>;\n\t\t\t\t\t\tqcom,level = <0x38>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x2>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x2>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x9>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x2>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x2>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x7>;\n\t\t\t\t\t\tqcom,acd-level = <0x882f5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#qcom9, 10 - old

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\t\tqcom,gpu-pwrlevel@9 {\n\t\t\t\t\t\treg = <0x09>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x12c684c0>;\n\t\t\t\t\t\tqcom,level = <0x40>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x02>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x02>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x09>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x02>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x02>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0x882f5ffd>;\n\t\t\t\t\t};', '\t\t\t\t\tqcom,gpu-pwrlevel@9 {\n\t\t\t\t\t\treg = <0x09>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x12c684c0>;\n\t\t\t\t\t\tqcom,level = <0x40>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x02>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x02>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x09>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x02>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x02>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0x882f5ffd>;\n\t\t\t\t\t};\n\n\t\t\t\t\tqcom,gpu-pwrlevel@10 {\n\t\t\t\t\t\treg = <0x0a>;\n\t\t\t\t\t\tqcom,gpu-freq = <0x8f0d180>;\n\t\t\t\t\t\tqcom,level = <0x38>;\n\t\t\t\t\t\tqcom,bus-freq-ddr7 = <0x02>;\n\t\t\t\t\t\tqcom,bus-min-ddr7 = <0x02>;\n\t\t\t\t\t\tqcom,bus-max-ddr7 = <0x09>;\n\t\t\t\t\t\tqcom,bus-freq-ddr8 = <0x02>;\n\t\t\t\t\t\tqcom,bus-min-ddr8 = <0x02>;\n\t\t\t\t\t\tqcom,bus-max-ddr8 = <0x07>;\n\t\t\t\t\t\tqcom,acd-level = <0x882f5ffd>;\n\t\t\t\t\t};')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:     
  f.write(new_data)