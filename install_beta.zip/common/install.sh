#!/bin/sh

MODDIR=${0%/*}
ui_print "-[Перед использованием модуля, ОБЯЗАТЕЛЬНО прочтите инструкцию!]-"
ui_print "-[Before using the module, BE SURE to read the instructions!]-"
ui_print "-[Если это сделано, нажмите Vol Up]-"
ui_print "-[If this is done, press Vol Up]-"
ui_print "-[Vol Up = Yes | Vol Down = No]-"
ui_print ""
ui_print ""
if $VKSEL; then
  mount /data
  mount -o rw,remount /data
  rm -R /data/adb/888
  mkdir -p /data/adb/888
  cp -a $MODDIR /data/adb/888
  unzip -q /data/adb/888/flash/install.zip -d /data/adb/888/
  rm -R /data/adb/888/__MACOSX
  rm -R /data/adb/888/flash
  ui_print "-[Select the desired module type: 3 types in total]-"
  ui_print ""
  ui_print ""
  ui_print "-[1) The first installation of the module]-"
  ui_print "-[Vol Up = Yes | Vol Down = No]-"
  if $VKSEL; then
    ui_print "**********************************************************************************"
    ui_print "*                         MMT Extended by Zackptg5 @ XDA                         *"
    ui_print "**********************************************************************************"
    ui_print "*  -Before installing, delete all my old modules!                                *"
    ui_print "*  -And stitch the original vendor_boot.img!                                     *"
    ui_print "*  -I am not responsible for any harm from the module!                           *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*             ------Optimizing Snapdragon 888 for Mi 11 Ultra------              *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                     Release - t.me/SNAP_888_OPTIMIZATION                       *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*  -You do everything at your own risk!                                          *"
    ui_print "*  -Enjoy using it!                                                              *"
    ui_print "**********************************************************************************"
    ui_print "*                    -Installation lasts - ≈1 minute,                            *"
    ui_print "*                    -please expect the inscription 'completed'!                 *"
    ui_print "**********************************************************************************"
    ui_print ""
    ui_print ""

    ui_print "-[Make a backup of the partition along the path /sdcard/888/vendor_boot.img?]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    ui_print " "
    if $VKSEL; then
      ui_print "->[   Backup           ]<-"
      ui_print "->[   Please wait...   ]<-"
      ui_print " "
      rm -R /sdcard/888
      mkdir /sdcard/888
      dd if=/dev/block/bootdevice/by-name/vendor_boot_a of=/sdcard/888/vendor_boot.img
    fi
    rm /sdcard/Android/vendor_boota.img
    rm /sdcard/Android/vendor_bootb.img
    dd if=/dev/block/bootdevice/by-name/vendor_boot_a of=/sdcard/Android/vendor_boota.img
    dd if=/dev/block/bootdevice/by-name/vendor_boot_b of=/sdcard/Android/vendor_bootb.img


    ui_print "-[To select CPU or GPU undervolting, press Vol Up]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    ui_print " "
    if $VKSEL; then
      mount /data
      mount -o rw,remount /data
      mkdir -p /data/user/0/com.termux
      mkdir -p /data/user/0/com.termux/files
      mkdir -p /data/user/0/com.termux/files/usr
      cp -a /data/adb/888/dtb/lib /data/user/0/com.termux/files/usr/
      dd if=/dev/block/bootdevice/by-name/vendor_boot_a of=/data/adb/888/dtb/vendor_boot.img
      dd if=/dev/block/bootdevice/by-name/boot_a of=/data/adb/888/dtb/boot_a.img
      cd /data/adb/888/dtb/; chmod +x magiskboot;
      cd /data/adb/888/dtb/; chmod +x dtc;
      cd /data/adb/888/dtb/; ./magiskboot unpack vendor_boot.img
      cd /data/adb/888/dtb/; chmod +x extract_dtb.py;
      cd /data/adb/888/dtb/; ./extract_dtb.py vendor_boot.img
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
      cp /data/adb/888/common/edit.py /data/adb/888/dtb/dtb1/ 
      cp /data/adb/888/common/cpu.py /data/adb/888/dtb/dtb1/ 
      ui_print ""
      ui_print "-[Do you want to do GPU undervolting?]-"
      ui_print "-[Vol Up = Yes | Vol Down = No]-"
      ui_print ""
      if $VKSEL; then
        ui_print "->[Please wait...]<-"
        cd /data/adb/888/dtb/dtb1/; chmod +x edit.py
        cd /data/adb/888/dtb/dtb1/; ./edit.py
        ui_print ""
      fi
      ui_print "-[Do you want to do CPU undervolting?]-"
      ui_print "-[Vol Up = Yes | Vol Down = No]-"
      ui_print ""
      if $VKSEL; then
        ui_print "->[Please wait...]<-"
        cd /data/adb/888/dtb/dtb1/; chmod +x cpu.py
        cd /data/adb/888/dtb/dtb1/; ./cpu.py
        ui_print ""
      fi
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
      cp /data/adb/888/dtb/magiskboot /data/adb/888/dtb/dtb1/
      cd /data/adb/888/dtb/dtb1/; chmod +x magiskboot
      cp /data/adb/888/dtb/vendor_boot.img /data/adb/888/dtb/dtb1/
      cp /data/adb/888/dtb/dtb /data/adb/888/dtb/dtb1/
      cp /data/adb/888/dtb/ramdisk.cpio /data/adb/888/dtb/dtb1/
      cd /data/adb/888/dtb/dtb1/; cat 01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb 02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb 03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb 04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb 05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb 06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb 07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb 08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb 09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb > dtb
      cd /data/adb/888/dtb/dtb1/; ./magiskboot repack vendor_boot.img 
      dd if=/data/adb/888/dtb/dtb1/new-boot.img of=/dev/block/bootdevice/by-name/vendor_boot_a
      dd if=/data/adb/888/dtb/dtb1/new-boot.img of=/dev/block/bootdevice/by-name/vendor_boot_b
    fi
    ui_print ""
    ui_print "-[Select the type of frequency restriction: 3 types in total]-"
    ui_print ""
    ui_print ""
    ui_print "-[1) Do full frequency limitation on GPU and CPU?]-"
    ui_print "-[CPU - PRIME - 2496; BIG - 2227; SMALL - 1612; GPU - 608 MAX]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    if $VKSEL; then
      cat /data/adb/888/common/cpuedit.sh /data/adb/888/common/gpu.sh > /data/adb/modules/snapdragon_888_optimization/service.sh
      cat /data/adb/888/common/cpuedit.sh /data/adb/888/common/gpu.sh > /data/adb/modules_update/snapdragon_888_optimization/service.sh
      exit
    fi
    ui_print ""
    ui_print "-[2) Add limits on max CPU frequency?]-"
    ui_print "-[PRIME - 2496; BIG - 2227; SMALL - 1612]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    ui_print ""
    if $VKSEL; then
      cat /data/adb/888/common/cpuedit.sh > /data/adb/modules/snapdragon_888_optimization/service.sh
      cat /data/adb/888/common/cpuedit.sh > /data/adb/modules_update/snapdragon_888_optimization/service.sh
      rm -R /data/adb/888
      exit
    fi
    ui_print ""
    ui_print "-[3) Add limits on the max GPU frequency?]-"
    ui_print "-[MAX - 608]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    ui_print " "
    if $VKSEL; then
      cat /data/adb/888/common/gpu.sh > /data/adb/modules/snapdragon_888_optimization/service.sh
      cat /data/adb/888/common/gpu.sh > /data/adb/modules_update/snapdragon_888_optimization/service.sh
    fi    
    rm -R /data/adb/888
    exit
  fi
  ui_print ""
  ui_print ""

  ui_print "-[2) Do you want to update the module?]-"
  ui_print "-[Vol Up = Yes | Vol Down = No]-"
  if $VKSEL; then
    ui_print "**********************************************************************************"
    ui_print "*                         MMT Extended by Zackptg5 @ XDA                         *"
    ui_print "**********************************************************************************"
    ui_print "*  -Before installing, delete all my old modules!                                *"
    ui_print "*  -And stitch the original vendor_boot.img!                                     *"
    ui_print "*  -I am not responsible for any harm from the module!                           *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*             ------Optimizing Snapdragon 888 for Mi 11 Ultra------              *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                     Release - t.me/SNAP_888_OPTIMIZATION                       *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*  -You do everything at your own risk!                                          *"
    ui_print "*  -Enjoy using it!                                                              *"
    ui_print "**********************************************************************************"
    ui_print "*                    -Installation lasts - ≈1 minute,                            *"
    ui_print "*                    -please expect the inscription 'completed'!                 *"
    ui_print "**********************************************************************************"
    ui_print ""
    ui_print ""

    ui_print " "
    dd if=/sdcard/Android/vendor_boota.img of=/dev/block/bootdevice/by-name/vendor_boot_a
    dd if=/sdcard/Android/vendor_bootb.img of=/dev/block/bootdevice/by-name/vendor_boot_b
    chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    echo 1612800 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    chmod 644 /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_max-freq
    echo 2419200 > /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_max-freq
    chmod 644 /sys/devices/system/cpu/cpufreq/policy7/cpuinfo_max-freq
    echo 2841600 > /sys/devices/system/cpu/cpufreq/policy7/cpuinfo_max-freq
    chmod 644 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
    echo 84000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
    chmod 644 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    echo 315 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    rm /data/adb/modules/snapdragon_888_optimization/service.sh
    cp /data/adb/888/common/service.sh /data/adb/modules/snapdragon_888_optimization/

    ui_print "-[Make a backup of the partition along the path /sdcard/888/vendor_boot.img?]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    ui_print " "
    if $VKSEL; then
      ui_print "->[   Backup           ]<-"
      ui_print "->[   Please wait...   ]<-"
      ui_print " "
      rm -R /sdcard/888
      mkdir /sdcard/888
      dd if=/dev/block/bootdevice/by-name/vendor_boot_a of=/sdcard/888/vendor_boot.img
    fi
    ui_print "-[To select CPU or GPU undervolting, press Vol Up]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    ui_print " "
    if $VKSEL; then
      mount /data
      mount -o rw,remount /data
      mkdir -p /data/user/0/com.termux
      mkdir -p /data/user/0/com.termux/files
      mkdir -p /data/user/0/com.termux/files/usr
      cp -a /data/adb/888/dtb/lib /data/user/0/com.termux/files/usr/
      dd if=/dev/block/bootdevice/by-name/vendor_boot_a of=/data/adb/888/dtb/vendor_boot.img
      dd if=/dev/block/bootdevice/by-name/boot_a of=/data/adb/888/dtb/boot_a.img
      cd /data/adb/888/dtb/; chmod +x magiskboot;
      cd /data/adb/888/dtb/; chmod +x dtc;
      cd /data/adb/888/dtb/; ./magiskboot unpack vendor_boot.img
      cd /data/adb/888/dtb/; chmod +x extract_dtb.py;
      cd /data/adb/888/dtb/; ./extract_dtb.py vendor_boot.img
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
      cd /data/adb/888/dtb/; ./dtc -I dtb /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb -O dts -o /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
      cp /data/adb/888/common/edit.py /data/adb/888/dtb/dtb1/ 
      cp /data/adb/888/common/cpu.py /data/adb/888/dtb/dtb1/ 
      ui_print ""
      ui_print "-[Do you want to do GPU undervolting?]-"
      ui_print "-[Vol Up = Yes | Vol Down = No]-"
      ui_print ""
      if $VKSEL; then
        ui_print "->[Please wait...]<-"
        cd /data/adb/888/dtb/dtb1/; chmod +x edit.py
        cd /data/adb/888/dtb/dtb1/; ./edit.py
        ui_print ""
      fi
      ui_print "-[Do you want to do CPU undervolting?]-"
      ui_print "-[Vol Up = Yes | Vol Down = No]-"
      ui_print ""
      if $VKSEL; then
        ui_print "->[Please wait...]<-"
        cd /data/adb/888/dtb/dtb1/; chmod +x cpu.py
        cd /data/adb/888/dtb/dtb1/; ./cpu.py
        ui_print ""
      fi
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb
      cd /data/adb/888/dtb/; ./dtc -I dts /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts -O dtb -o /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
      cd /data/adb/888/dtb/dtb1/; rm /data/adb/888/dtb/dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
      cp /data/adb/888/dtb/magiskboot /data/adb/888/dtb/dtb1/
      cd /data/adb/888/dtb/dtb1/; chmod +x magiskboot
      cp /data/adb/888/dtb/vendor_boot.img /data/adb/888/dtb/dtb1/
      cp /data/adb/888/dtb/dtb /data/adb/888/dtb/dtb1/
      cp /data/adb/888/dtb/ramdisk.cpio /data/adb/888/dtb/dtb1/
      cd /data/adb/888/dtb/dtb1/; cat 01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb 02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb 03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb 04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb 05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb 06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb 07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb 08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb 09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb > dtb
      cd /data/adb/888/dtb/dtb1/; ./magiskboot repack vendor_boot.img 
      dd if=/data/adb/888/dtb/dtb1/new-boot.img of=/dev/block/bootdevice/by-name/vendor_boot_a
      dd if=/data/adb/888/dtb/dtb1/new-boot.img of=/dev/block/bootdevice/by-name/vendor_boot_b
    fi
    ui_print ""
    ui_print "-[Select the type of frequency restriction: 3 types in total]-"
    ui_print ""
    ui_print ""
    ui_print "-[1) Do full frequency limitation on GPU and CPU?]-"
    ui_print "-[CPU - PRIME - 2496; BIG - 2227; SMALL - 1612; GPU - 608 MAX]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    if $VKSEL; then
      cat /data/adb/888/common/cpuedit.sh /data/adb/888/common/gpu.sh > /data/adb/modules/snapdragon_888_optimization/service.sh
      cat /data/adb/888/common/cpuedit.sh /data/adb/888/common/gpu.sh > /data/adb/modules_update/snapdragon_888_optimization/service.sh
      exit
    fi
    ui_print ""
    ui_print "-[2) Add limits on max CPU frequency?]-"
    ui_print "-[PRIME - 2496; BIG - 2227; SMALL - 1612]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    ui_print ""
    if $VKSEL; then
      cat /data/adb/888/common/cpuedit.sh > /data/adb/modules/snapdragon_888_optimization/service.sh
      cat /data/adb/888/common/cpuedit.sh > /data/adb/modules_update/snapdragon_888_optimization/service.sh
      rm -R /data/adb/888
      exit
    fi
    ui_print ""
    ui_print "-[3) Add limits on the max GPU frequency?]-"
    ui_print "-[MAX - 608]-"
    ui_print "-[Vol Up = Yes | Vol Down = No]-"
    ui_print " "
    if $VKSEL; then
      cat /data/adb/888/common/gpu.sh > /data/adb/modules/snapdragon_888_optimization/service.sh
      cat /data/adb/888/common/gpu.sh > /data/adb/modules_update/snapdragon_888_optimization/service.sh
    fi    
    rm -R /data/adb/888
    exit
  fi
  ui_print ""
  ui_print ""
  ui_print "-[3) Restore the value drain of all changes?]-"
  ui_print "-[Required only after module installation or CPU/GPU limitations]-"
  ui_print "-[If you want to delete, change the module]-"
  ui_print "-[Vol Up = Yes | Vol Down = No]-"
  ui_print " "
  if $VKSEL; then
    dd if=/sdcard/Android/vendor_boota.img of=/dev/block/bootdevice/by-name/vendor_boot_a
    dd if=/sdcard/Android/vendor_bootb.img of=/dev/block/bootdevice/by-name/vendor_boot_b
    chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    echo 1612800 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    chmod 644 /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_max-freq
    echo 2419200 > /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_max-freq
    chmod 644 /sys/devices/system/cpu/cpufreq/policy7/cpuinfo_max-freq
    echo 2841600 > /sys/devices/system/cpu/cpufreq/policy7/cpuinfo_max-freq
    chmod 644 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
    echo 84000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
    chmod 644 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    echo 315 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    rm /data/adb/modules/snapdragon_888_optimization/service.sh
    cp /data/adb/888/common/service.sh /data/adb/modules/snapdragon_888_optimization/
    rm -R /data/adb/modules/snapdragon_888_optimization
    ui_print "Recovery is complete"
    rm -R /data/adb/modules_update/snapdragon_888_optimization
    exit
  fi
  exit
fi
rm -R /data/adb/modules_update/snapdragon_888_optimization
rm /data/adb/modules_update/snapdragon_888_optimization/update
exit