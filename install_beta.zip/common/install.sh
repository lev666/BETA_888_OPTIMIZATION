#!/bin/sh

adb="/data/adb"
MODDIR=${0%/*}
MODD="/data/adb/888"
BACKUP="/sdcard/888"
VENDORABdev="/dev/block/bootdevice/by-name"
VENDORABand="/sdcard/Android"
dtb="$MODD/dtb"
dtb1="$MODD/dtb/dtb1"

ui_print ""
ui_print ""
ui_print "-[Перед использованием модуля, ОБЯЗАТЕЛЬНО прочтите инструкцию!]-"
ui_print "-[Если это сделано, нажмите Громкость вверх]-"
ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
ui_print ""
ui_print ""
if $VKSEL; then
  rm -R $adb/888
  mkdir -p $adb/888
  cp -a $MODDIR $MODD/
  unzip -q $MODD/flash/install.zip -d $MODD/
  rm -R $MODD/__MACOSX
  rm -R $MODD/flash
  ui_print "-[Выберите тип использования модуля (всего 4 типа)]-"
  ui_print "1) Готовые настройки от автора 2) Первичная установка(с выбором)"
  ui_print "3) Обновление модуля 4) Удаление модуля(восстановление стоковых значений)"
  ui_print ""
  ui_print ""
  ui_print "-[1) Применить готовые настройки от автора]-?"
  ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
	   if $VKSEL; then
	     ui_print ""
         ui_print ""
	     ui_print "**********************************************************************************"
         ui_print "*                         MMT Extended by Zackptg5 @ XDA                         *"
         ui_print "**********************************************************************************"
         ui_print "*                                                                                *"
         ui_print "*                                                                                *"
         ui_print "*                                                                                *"
         ui_print "*                  ------EcoSaver888 for Mi 11 Ultra------                       *"
         ui_print "*                                                                                *"
         ui_print "*                                                                                *"
         ui_print "*                 Release - https://t.me/EcoSaver888_Update                      *"
         ui_print "*                                                                                *"
         ui_print "*                                                                                *"
         ui_print "*                                                                                *"
         ui_print "*  - Вы делаете всё на свой страх и риск!                                        *"
         ui_print "*  - Приятного использования!                                                    *"
         ui_print "**********************************************************************************"
         ui_print "*                    - Установка длится - ≈ 1 минуту,                            *"
         ui_print "*                    - Пожалуйста ожидайте надписи 'Завершено'!                  *"
         ui_print "**********************************************************************************"
		 ui_print ""
         ui_print ""
		 ui_print "-[Вы обновляете модуль?]-"
		 ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
		 if $VKSEL; then
           dd if=$VENDORABand/vendor_boota.img of=$VENDORABdev/vendor_boot_a
           dd if=$VENDORABand/vendor_bootb.img of=$VENDORABdev/vendor_boot_b
		 fi
	     ui_print ""
         ui_print ""
		 ui_print "-[Сделать резервную копию раздела? (Соглашаться только при первичной установки модуля!)]-"
		 ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
		 if $VKSEL; then
		   ui_print ""
		   ui_print "->[Резервное копирование vendor_boot по пути /sdcard/888/]<-"
		   ui_print "->[   Пожалуйста ожидайте...   ]<-"
           rm -R $BACKUP
           mkdir $BACKUP
           dd if=$VENDORABdev/vendor_boot_a of=$BACKUP/vendor_boot.img
		 fi
         ui_print " "
		 ui_print " "
		 ui_print "->[Применение андервольтинга GPU(видео-ядро)]<-"
		 ui_print "->[Пожалуйста ожидайте...]<-"
		 rm $VENDORABand/vendor_boota.img
         rm $VENDORABand/vendor_bootb.img
         dd if=$VENDORABdev/vendor_boot_a of=$VENDORABand/vendor_boota.img
         dd if=$VENDORABdev/vendor_boot_b of=$VENDORABand/vendor_bootb.img
		 mount /data
         mount -o rw,remount /data
         mkdir -p /data/user/0/com.termux
         mkdir -p /data/user/0/com.termux/files
         mkdir -p /data/user/0/com.termux/files/usr
         cp -a $dtb/lib /data/user/0/com.termux/files/usr/
         dd if=$VENDORABdev/vendor_boot_a of=$dtb/vendor_boot.img
         #dd if=$VENDORABdev/boot_a of=$dtb/boot_a.img
         cd $dtb/; chmod +x magiskboot;
         cd $dtb/; chmod +x dtc;
		 cd $dtb/bin; chmod +x python3;
         cd $dtb/; ./magiskboot unpack vendor_boot.img
         cd $dtb/; /data/adb/888/dtb/bin/python3 /$MODD/dtb/extract_dtb.py vendor_boot.img
         cd $dtb/; ./dtc -I dtb $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb -O dts -o $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
         cd $dtb/; ./dtc -I dtb $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb -O dts -o $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
         cd $dtb/; ./dtc -I dtb $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb -O dts -o $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
         cd $dtb/; ./dtc -I dtb $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb -O dts -o $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
         cd $dtb/; ./dtc -I dtb $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb -O dts -o $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
         cd $dtb/; ./dtc -I dtb $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb -O dts -o $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
         cd $dtb/; ./dtc -I dtb $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb -O dts -o $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
         cd $dtb/; ./dtc -I dtb $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb -O dts -o $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
         cd $dtb/; ./dtc -I dtb $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb -O dts -o $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
         cp $MODD/common/OC1.py $dtb1/ 
         cp $MODD/common/OC2.py $dtb1/
         cp $MODD/common/OC3.py $dtb1/
         cp $MODD/common/OC4.py $dtb1/
         cp $MODD/common/cpu.py $dtb1/ 
		 cd $dtb1/; chmod +x OC1.py
         cd $dtb1/; ./OC1.py
         cd $dtb/; ./dtc -I dts $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts -O dtb -o $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb
         cd $dtb/; ./dtc -I dts $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts -O dtb -o $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb
         cd $dtb/; ./dtc -I dts $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts -O dtb -o $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb
         cd $dtb/; ./dtc -I dts $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts -O dtb -o $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb
         cd $dtb/; ./dtc -I dts $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts -O dtb -o $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb
         cd $dtb/; ./dtc -I dts $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts -O dtb -o $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb
         cd $dtb/; ./dtc -I dts $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts -O dtb -o $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb
         cd $dtb/; ./dtc -I dts $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts -O dtb -o $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb
         cd $dtb/; ./dtc -I dts $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts -O dtb -o $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb
         cd $dtb1/; rm $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
         cd $dtb1/; rm $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
         cd $dtb1/; rm $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
         cd $dtb1/; rm $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
         cd $dtb1/; rm $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
         cd $dtb1/; rm $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
         cd $dtb1/; rm $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
         cd $dtb1/; rm $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
         cd $dtb1/; rm $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
         cp $dtb/magiskboot $dtb1/
         cd $dtb1/; chmod +x magiskboot
         cp $dtb/vendor_boot.img $dtb1/
         cp $dtb/dtb $dtb1/
         cp $dtb/ramdisk.cpio $dtb1/
         cd $dtb1/; cat 01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb 02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb 03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb 04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb 05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb 06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb 07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb 08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb 09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb > dtb
         cd $dtb1/; ./magiskboot repack vendor_boot.img 
         dd if=$dtb1/new-boot.img of=$VENDORABdev/vendor_boot_a
         dd if=$dtb1/new-boot.img of=$VENDORABdev/vendor_boot_b
		 ui_print ""
         ui_print ""
		 ui_print "-[Ограничение частот на GPU(видео-ядро) и CPU(процессор)]-"
         ui_print "-[CPU(ядра) - PRIME - 2496; BIG - 2227; SMALL - 1612; GPU - 608]-"
         cat $MODD/common/cpuedit.sh $MODD/common/gpu.sh > /data/adb/modules/EcoSaver888/service.sh
         cat $MODD/common/cpuedit.sh $MODD/common/gpu.sh > /data/adb/modules_update/EcoSaver888/service.sh
		 rm -R $MODD
		 exit
       fi
  ui_print ""
  ui_print ""  
  ui_print "-[2) Начать первичную установку?]-"
  ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
  if $VKSEL; then
    ui_print "**********************************************************************************"
    ui_print "*                         MMT Extended by Zackptg5 @ XDA                         *"
    ui_print "**********************************************************************************"
    ui_print "*  - Перед установкой, удалите мои старые модули!                                *"
    ui_print "*  - Используйте оригинальный vendor_boot раздел!                                *"
    ui_print "*  - Я не несу ответственности за приченённый вред от модуля!                    *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                  ------EcoSaver888 for Mi 11 Ultra------                       *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                 Release - https://t.me/EcoSaver888_Update                      *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*  - Вы делаете всё на свой страх и риск!                                        *"
    ui_print "*  - Приятного использования!                                                    *"
    ui_print "**********************************************************************************"
    ui_print "*                    - Установка длится - ≈ 1 минуту,                            *"
    ui_print "*                    - Пожалуйста ожидайте надписи 'Завершено'!                  *"
    ui_print "**********************************************************************************"
    ui_print ""
    ui_print ""

    ui_print "-[Сделать бэкап раздела vendor_boot по пути /sdcard/888/?]-"
	ui_print "-[Соглашаться только при первичной установки модуля!]-"
    ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
    ui_print " "
    if $VKSEL; then
      ui_print "->[   Резервное копирование    ]<-"
      ui_print "->[   Пожалуйста ожидайте...   ]<-"
      ui_print " "
      rm -R $BACKUP
      mkdir $BACKUP
      dd if=$VENDORABdev/vendor_boot_a of=$BACKUP/vendor_boot.img
    fi
    rm $VENDORABand/vendor_boota.img
    rm $VENDORABand/vendor_bootb.img
    dd if=$VENDORABdev/vendor_boot_a of=$VENDORABand/vendor_boota.img
    dd if=$VENDORABdev/vendor_boot_b of=$VENDORABand/vendor_bootb.img
      mount /data
      mount -o rw,remount /data
      mkdir -p /data/user/0/com.termux
      mkdir -p /data/user/0/com.termux/files
      mkdir -p /data/user/0/com.termux/files/usr
      cp -a $dtb/lib /data/user/0/com.termux/files/usr/
      dd if=$VENDORABdev/vendor_boot_a of=$dtb/vendor_boot.img
      #dd if=$VENDORABdev/boot_a of=$dtb/boot_a.img
      cd $dtb/; chmod +x magiskboot;
      cd $dtb/; chmod +x dtc;
      cd $dtb/bin; chmod +x python3;
      cd $dtb/; ./magiskboot unpack vendor_boot.img
      cd $dtb/; /data/adb/888/dtb/bin/python3 /$MODD/dtb/extract_dtb.py vendor_boot.img
      cd $dtb/; ./dtc -I dtb $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb -O dts -o $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb -O dts -o $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb -O dts -o $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb -O dts -o $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb -O dts -o $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb -O dts -o $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb -O dts -o $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb -O dts -o $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb -O dts -o $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
      cp $MODD/common/OC1.py $dtb1/ 
      cp $MODD/common/OC2.py $dtb1/
      cp $MODD/common/OC3.py $dtb1/
      cp $MODD/common/OC4.py $dtb1/
      cp $MODD/common/cpu.py $dtb1/ 
        ui_print ""
        ui_print ""
        ui_print "-[Вам будет предложено на выбор 4 типа андервольтнга GPU. Значение каждого даны в инструкции]-"
        ui_print "-[Выбрать нужно только один!!!]-"
		ui_print "-[Пример - Выбрали вы OC1, то на остальные варианты вы нажимаете Громкость Вниз!]-"
        ui_print ""
        ui_print "-[1) Андервольтинг GPU(видео-ядро) по OC1(Рекомендуется для всех)]-"
        ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
        if $VKSEL; then
		  ui_print ""
          ui_print "->[Пожалуйста ожидайте...]<-"
          cd $dtb1/; chmod +x OC1.py
          cd $dtb1/; ./OC1.py
          ui_print ""
        fi
		ui_print ""
        ui_print "-[2) Андервольтинг GPU(видео-ядро) по OC2(Не для всех)]-"
        ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
        if $VKSEL; then
		  ui_print ""
          ui_print "->[Пожалуйста ожидайте...]<-"
          cd $dtb1/; chmod +x OC2.py
          cd $dtb1/; ./OC2.py
          ui_print ""
        fi
		ui_print ""
        ui_print "-[3) Андервольтинг GPU(видео-ядро) по OC3(Не для всех)]-"
        ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
        if $VKSEL; then
		  ui_print ""
          ui_print "->[Пожалуйста ожидайте...]<-"
          cd $dtb1/; chmod +x OC3.py
          cd $dtb1/; ./OC3.py
          ui_print ""
        fi
		ui_print ""
        ui_print "-[4) Андервольтинг GPU(видео-ядро) по OC4(Малый шанс успеха)]-"
        ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
        if $VKSEL; then
		  ui_print ""
          ui_print "->[Пожалуйста ожидайте...]<-"
          cd $dtb1/; chmod +x OC4.py
          cd $dtb1/; ./OC4.py
		  ui_print ""
        fi
		ui_print ""
		ui_print "-[Применение андервольтинга]-"
		ui_print "->[Пожалуйста ожидайте...]<-"
      #ui_print "-[Do you want to do CPU undervolting?]-"
      #ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
      #ui_print ""
      #if $VKSEL; then
        #ui_print "->[Пожалуйста ожидайте...]<-"
        #cd $dtb1/; chmod +x cpu.py
        #cd $dtb1/; ./cpu.py
        #ui_print ""
      #fi
      cd $dtb/; ./dtc -I dts $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts -O dtb -o $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts -O dtb -o $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts -O dtb -o $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts -O dtb -o $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts -O dtb -o $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts -O dtb -o $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts -O dtb -o $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts -O dtb -o $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts -O dtb -o $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb
      cd $dtb1/; rm $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
      cd $dtb1/; rm $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
      cd $dtb1/; rm $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
      cd $dtb1/; rm $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
      cd $dtb1/; rm $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
      cd $dtb1/; rm $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
      cd $dtb1/; rm $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
      cd $dtb1/; rm $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
      cd $dtb1/; rm $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
      cp $dtb/magiskboot $dtb1/
      cd $dtb1/; chmod +x magiskboot
      cp $dtb/vendor_boot.img $dtb1/
      cp $dtb/dtb $dtb1/
      cp $dtb/ramdisk.cpio $dtb1/
      cd $dtb1/; cat 01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb 02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb 03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb 04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb 05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb 06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb 07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb 08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb 09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb > dtb
      cd $dtb1/; ./magiskboot repack vendor_boot.img 
      dd if=$dtb1/new-boot.img of=$VENDORABdev/vendor_boot_a
      dd if=$dtb1/new-boot.img of=$VENDORABdev/vendor_boot_b
    #ui_print "-[Select the type of frequency restriction: 3 types in total]-"
    ui_print ""
    ui_print ""
    ui_print "-[Ограничить частоты на GPU(видео-ядро) и CPU(процессор)?]-"
    ui_print "-[CPU(ядра) - PRIME - 2496; BIG - 2227; SMALL - 1612; GPU - 608]-"
    ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
    if $VKSEL; then
      cat $MODD/common/cpuedit.sh $MODD/common/gpu.sh > /data/adb/modules/EcoSaver888/service.sh
      cat $MODD/common/cpuedit.sh $MODD/common/gpu.sh > /data/adb/modules_update/EcoSaver888/service.sh
      exit
    fi
    #ui_print ""
    #ui_print "-[2) Add limits on max CPU frequency?]-"
    #ui_print "-[PRIME - 2496; BIG - 2227; SMALL - 1612]-"
    #ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
    #ui_print ""
    #if $VKSEL; then
      #cat $MODD/common/cpuedit.sh > /data/adb/modules/EcoSaver888/service.sh
      #cat $MODD/common/cpuedit.sh > /data/adb/modules_update/EcoSaver888/service.sh
      #rm -R $MODD
      #exit
    #fi
    #ui_print ""
    #ui_print "-[3) Add limits on the max GPU frequency?]-"
    #ui_print "-[MAX - 608]-"
    #ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
    #ui_print " "
    #if $VKSEL; then
      #cat $MODD/common/gpu.sh > /data/adb/modules/EcoSaver888/service.sh
      #cat $MODD/common/gpu.sh > /data/adb/modules_update/EcoSaver888/service.sh
    #fi    
    rm -R $MODD
    exit
  fi
  ui_print ""
  ui_print ""

  ui_print "-[3) Вы хотите обновить модуль?]-"
  ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
  if $VKSEL; then
    ui_print "**********************************************************************************"
    ui_print "*                         MMT Extended by Zackptg5 @ XDA                         *"
    ui_print "**********************************************************************************"
    ui_print "*  - Перед установкой, удалите мои старые модули!                                *"
    ui_print "*  - Используйте оригинальный vendor_boot раздел!                                *"
    ui_print "*  - Я не несу ответственности за приченённый вред от модуля!                    *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                  ------EcoSaver888 for Mi 11 Ultra------                       *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                 Release - https://t.me/EcoSaver888_Update                      *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*                                                                                *"
    ui_print "*  - Вы делаете всё на свой страх и риск!                                        *"
    ui_print "*  - Приятного использования!                                                    *"
    ui_print "**********************************************************************************"
    ui_print "*                    - Установка длится - ≈ 1 минуту,                            *"
    ui_print "*                    - Пожалуйста ожидайте надписи 'Завершено'!                  *"
    ui_print "**********************************************************************************"
    ui_print ""
    ui_print ""

    ui_print " "
    dd if=$VENDORABand/vendor_boota.img of=$VENDORABdev/vendor_boot_a
    dd if=$VENDORABand/vendor_bootb.img of=$VENDORABdev/vendor_boot_b
    chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    echo 1612800 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    chmod 644 /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_max-freq
    echo 2419200 > /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_max-freq
    chmod 644 /sys/devices/system/cpu/cpufreq/policy7/cpuinfo_max-freq
    echo 2841600 > /sys/devices/system/cpu/cpufreq/policy7/cpuinfo_max-freq
    chmod 644 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
    echo 84000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
    chmod 644 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    echo 315 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    rm /data/adb/modules/EcoSaver888/service.sh
    cp $MODD/common/service.sh /data/adb/modules/EcoSaver888/

    ui_print "-[Сделать бэкап раздела vendor_boot по пути /sdcard/888/?]-"
    ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
    ui_print " "
    if $VKSEL; then
      ui_print "->[   Резервное копирование    ]<-"
      ui_print "->[   Пожалуйста ожидайте...   ]<-"
      ui_print " "
      rm -R $BACKUP
      mkdir $BACKUP
      dd if=$VENDORABdev/vendor_boot_a of=$BACKUP/vendor_boot.img
    fi
      mount /data
      mount -o rw,remount /data
      mkdir -p /data/user/0/com.termux
      mkdir -p /data/user/0/com.termux/files
      mkdir -p /data/user/0/com.termux/files/usr
      cp -a $dtb/lib /data/user/0/com.termux/files/usr/
      dd if=$VENDORABdev/vendor_boot_a of=$dtb/vendor_boot.img
      dd if=$VENDORABdev/boot_a of=$dtb/boot_a.img
      cd $dtb/; chmod +x magiskboot;
      cd $dtb/; chmod +x dtc;
      cd $dtb/; ./magiskboot unpack vendor_boot.img
      cd $dtb/; chmod +x extract_dtb.py;
      cd $dtb/; ./extract_dtb.py vendor_boot.img
      cd $dtb/; ./dtc -I dtb $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb -O dts -o $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb -O dts -o $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb -O dts -o $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb -O dts -o $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb -O dts -o $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb -O dts -o $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb -O dts -o $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb -O dts -o $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
      cd $dtb/; ./dtc -I dtb $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb -O dts -o $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
      cp $MODD/common/OC1.py $dtb1/ 
      cp $MODD/common/OC2.py $dtb1/
      cp $MODD/common/OC3.py $dtb1/
      cp $MODD/common/OC4.py $dtb1/
      cp $MODD/common/cpu.py $dtb1/ 
      ui_print ""
      ui_print ""
      ui_print "-[Вам будет предложено на выбор 4 типа андервольтнга GPU. Значение каждого даны в инструкции]-"
      ui_print "-[Выбрать нужно только один!!!]-"
      ui_print "-[Пример - Выбрали вы OC1, то на остальные варианты вы нажимаете Громкость Вниз!]-"
      ui_print ""
      ui_print "-[1) Андервольтинг GPU(видео-ядро) по OC1(Рекомендуется для всех)]-"
      ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
      if $VKSEL; then
	    ui_print ""
        ui_print "->[Пожалуйста ожидайте...]<-"
        cd $dtb1/; chmod +x OC1.py
        cd $dtb1/; ./OC1.py
        ui_print ""
      fi
      ui_print ""
      ui_print "-[2) Андервольтинг GPU(видео-ядро) по OC2(Не для всех)]-"
      ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
      if $VKSEL; then
		ui_print ""
        ui_print "->[Пожалуйста ожидайте...]<-"
        cd $dtb1/; chmod +x OC2.py
        cd $dtb1/; ./OC2.py
        ui_print ""
      fi
	  ui_print ""
      ui_print "-[3) Андервольтинг GPU(видео-ядро) по OC3(Не для всех)]-"
      ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
      if $VKSEL; then
		ui_print ""
        ui_print "->[Пожалуйста ожидайте...]<-"
        cd $dtb1/; chmod +x OC3.py
        cd $dtb1/; ./OC3.py
        ui_print ""
      fi
      ui_print ""
      ui_print "-[4) Андервольтинг GPU(видео-ядро) по OC4(Малый шанс успеха)]-"
      ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
      if $VKSEL; then
		ui_print ""
        ui_print "->[Пожалуйста ожидайте...]<-"
        cd $dtb1/; chmod +x OC4.py
        cd $dtb1/; ./OC4.py
		ui_print ""
      fi
      ui_print ""
      ui_print "-[Применение андервольтинга]-"
	  ui_print "->[Пожалуйста ожидайте...]<-"
      #ui_print "-[Do you want to do CPU undervolting?]-"
      #ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
      #ui_print ""
      #if $VKSEL; then
        #ui_print "->[Пожалуйста ожидайте...]<-"
        #cd $dtb1/; chmod +x cpu.py
        #cd $dtb1/; ./cpu.py
        #ui_print ""
      #fi
      cd $dtb/; ./dtc -I dts $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts -O dtb -o $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts -O dtb -o $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts -O dtb -o $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts -O dtb -o $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts -O dtb -o $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts -O dtb -o $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts -O dtb -o $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts -O dtb -o $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb
      cd $dtb/; ./dtc -I dts $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts -O dtb -o $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb
      cd $dtb1/; rm $dtb1/01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts
      cd $dtb1/; rm $dtb1/02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dts
      cd $dtb1/; rm $dtb1/03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dts
      cd $dtb1/; rm $dtb1/04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dts
      cd $dtb1/; rm $dtb1/05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dts
      cd $dtb1/; rm $dtb1/06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dts
      cd $dtb1/; rm $dtb1/07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dts
      cd $dtb1/; rm $dtb1/08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dts
      cd $dtb1/; rm $dtb1/09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dts
      cp $dtb/magiskboot $dtb1/
      cd $dtb1/; chmod +x magiskboot
      cp $dtb/vendor_boot.img $dtb1/
      cp $dtb/dtb $dtb1/
      cp $dtb/ramdisk.cpio $dtb1/
      cd $dtb1/; cat 01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dtb 02_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2_SoC.dtb 03_dtbdump_Qualcomm_Technologies,_Inc._lahaina_v1_SoC.dtb 04_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2.1_SoC.dtb 05_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_v2_SoC.dtb 06_dtbdump_Qualcomm_Technologies,_Inc._LahianaP_SoC.dtb 07_dtbdump_Qualcomm_Technologies,_Inc._Shima_SoC.dtb 08_dtbdump_Qualcomm_Technologies,_Inc._Yupik_SoC.dtb 09_dtbdump_Qualcomm_Technologies,_Inc._YupikP_SoC.dtb > dtb
      cd $dtb1/; ./magiskboot repack vendor_boot.img 
      dd if=$dtb1/new-boot.img of=$VENDORABdev/vendor_boot_a
      dd if=$dtb1/new-boot.img of=$VENDORABdev/vendor_boot_b
    #ui_print "-[Select the type of frequency restriction: 3 types in total]-"
    ui_print ""
    ui_print ""
    ui_print "-[Ограничить частоты на GPU(видео-ядро) и CPU(процессор)?]-"
    ui_print "-[CPU(ядра) - PRIME - 2496; BIG - 2227; SMALL - 1612; GPU - 608]-"
    ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
    if $VKSEL; then
      cat $MODD/common/cpuedit.sh $MODD/common/gpu.sh > /data/adb/modules/EcoSaver888/service.sh
      cat $MODD/common/cpuedit.sh $MODD/common/gpu.sh > /data/adb/modules_update/EcoSaver888/service.sh
      exit
    fi
    #ui_print ""
    #ui_print "-[2) Add limits on max CPU frequency?]-"
    #ui_print "-[PRIME - 2496; BIG - 2227; SMALL - 1612]-"
    #ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
    #ui_print ""
    #if $VKSEL; then
      #cat $MODD/common/cpuedit.sh > /data/adb/modules/EcoSaver888/service.sh
      #cat $MODD/common/cpuedit.sh > /data/adb/modules_update/EcoSaver888/service.sh
      #rm -R $MODD
      #exit
    #fi
    #ui_print ""
    #ui_print "-[3) Add limits on the max GPU frequency?]-"
    #ui_print "-[MAX - 608]-"
    #ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
    #ui_print " "
    #if $VKSEL; then
      #cat $MODD/common/gpu.sh > /data/adb/modules/EcoSaver888/service.sh
      #cat $MODD/common/gpu.sh > /data/adb/modules_update/EcoSaver888/service.sh
    #fi    
    rm -R $MODD
    exit
  fi
  ui_print ""
  ui_print ""
  ui_print "-[4) Выполнить удаление модуля(возвращение стоковых значений)?]-"
  ui_print "-[Обязательно условие: использовать после установки модуля и первой перезагрузки после установки!]-"
  ui_print "-[Громкость вверх = Да | Громкость вниз = Нет]-"
  ui_print " "
  if $VKSEL; then
    ui_print "->[   Пожалуйста ожидайте...   ]<-"
    dd if=$VENDORABand/vendor_boota.img of=$VENDORABdev/vendor_boot_a
    dd if=$VENDORABand/vendor_bootb.img of=$VENDORABdev/vendor_boot_b
    chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    echo 1612800 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    chmod 644 /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_max-freq
    echo 2419200 > /sys/devices/system/cpu/cpufreq/policy4/cpuinfo_max-freq
    chmod 644 /sys/devices/system/cpu/cpufreq/policy7/cpuinfo_max-freq
    echo 2841600 > /sys/devices/system/cpu/cpufreq/policy7/cpuinfo_max-freq
    chmod 644 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
    echo 84000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
    chmod 644 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    echo 315 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    rm /data/adb/modules/EcoSaver888/service.sh
    cp $MODD/common/service.sh /data/adb/modules/EcoSaver888/
    rm -R /data/adb/modules/EcoSaver888
	ui_print ""
    ui_print "Recovery is complete"
    rm -R /data/adb/modules_update/EcoSaver888
    exit
  fi
  exit
fi
rm -R /data/adb/modules_update/EcoSaver888
rm /data/adb/modules_update/EcoSaver888/update
exit