#!/data/adb/888/dtb/bin/python3

#MXC and CX LVL

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage-level = <0x180>;', 'qcom,init-voltage-level = <0x160>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-max-microvolt = <0xffff>;', 'regulator-max-microvolt = <0x190>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,proxy-consumer-voltage = <0x180 0xffff>;', 'qcom,proxy-consumer-voltage = <0x160 0x190>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

###  GFXLVL

#smpb10 - no touch!!!!

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "smpb10";\n\n\t\t\t\tregulator-pm8350-s10 {\n\t\t\t\t\tregulator-name = "pm8350_s10";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1b7740>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;', '\t\t\t\tqcom,resource-name = "smpb10";\n\n\t\t\t\tregulator-pm8350-s10 {\n\t\t\t\t\tregulator-name = "pm8350_s10";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7358>;\n\t\t\t\t\tregulator-max-microvolt = <0x1b7358>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7358>;')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#smpb11

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "smpb11";\n\n\t\t\t\tregulator-pm8350-s11 {\n\t\t\t\t\tregulator-name = "pm8350_s11";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xb7980>;\n\t\t\t\t\tregulator-max-microvolt = <0xf7120>;\n\t\t\t\t\tqcom,init-voltage = <0xe86c0>;', '\t\t\t\tqcom,resource-name = "smpb11";\n\n\t\t\t\tregulator-pm8350-s11 {\n\t\t\t\t\tregulator-name = "pm8350_s11";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xb7980>;\n\t\t\t\t\tregulator-max-microvolt = <0xf6d38>;\n\t\t\t\t\tqcom,init-voltage = <0xe86c0>;')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

###  LCXLVL

#ldob9 - no  touch!!!!!!

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldob9";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pm8350-l9 {\n\t\t\t\t\tregulator-name = "pm8350_l9";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124f80>;\n\t\t\t\t\tregulator-max-microvolt = <0x124f80>;\n\t\t\t\t\tqcom,init-voltage = <0x124f80>;\n', '\t\t\t\tqcom,resource-name = "ldob9";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pm8350-l9 {\n\t\t\t\t\tregulator-name = "pm8350_l9";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124b98>;\n\t\t\t\t\tregulator-max-microvolt = <0x124b98>;\n\t\t\t\t\tqcom,init-voltage = <0x124b98>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#smpc1

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "smpc1";\n\n\t\t\t\tregulator-pm8350c-s1 {\n\t\t\t\t\tregulator-name = "pm8350c_s1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1dc900>;\n\t\t\t\t\tqcom,init-voltage = <0x1cafc0>;\n', '\t\t\t\tqcom,resource-name = "smpc1";\n\n\t\t\t\tregulator-pm8350c-s1 {\n\t\t\t\t\tregulator-name = "pm8350c_s1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x7a120>;\n\t\t\t\t\tqcom,init-voltage = <0x1cafc0>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

###  EBILVL

#smpc3

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "smpc3";\n\n\t\t\t\tregulator-pm8350c-s3 {\n\t\t\t\t\tregulator-name = "pm8350c_s3";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x493e0>;\n\t\t\t\t\tregulator-max-microvolt = <0xabe00>;\n\t\t\t\t\tqcom,init-voltage = <0x79180>;\n', '\t\t\t\tqcom,resource-name = "smpc3";\n\n\t\t\t\tregulator-pm8350c-s3 {\n\t\t\t\t\tregulator-name = "pm8350c_s3";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x493e0>;\n\t\t\t\t\tregulator-max-microvolt = <0x7c830>;\n\t\t\t\t\tqcom,init-voltage = <0x79180>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

###  MMCXlvl

#smpc10

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "smpc10";\n\n\t\t\t\tregulator-pm8350c-s10 {\n\t\t\t\t\tregulator-name = "pm8350c_s10";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xffdc0>;\n\t\t\t\t\tregulator-max-microvolt = <0x113640>;\n\t\t\t\t\tqcom,init-voltage = <0xffdc0>;', '\t\t\t\tqcom,resource-name = "smpc10";\n\n\t\t\t\tregulator-pm8350c-s10 {\n\t\t\t\t\tregulator-name = "pm8350c_s10";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xffdc0>;\n\t\t\t\t\tregulator-max-microvolt = <0x101918>;\n\t\t\t\t\tqcom,init-voltage = <0xffdc0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc1

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-pm8350c-l1 {\n\t\t\t\t\tregulator-name = "pm8350c_l1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1b7740>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;', 'regulator-pm8350c-l1 {\n\t\t\t\t\tregulator-name = "pm8350c_l1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xf4240>;\n\t\t\t\t\tregulator-max-microvolt = <0xf4240>;\n\t\t\t\t\tqcom,init-voltage = <0xf4240>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-pm8350c-l1-ao {\n\t\t\t\t\tregulator-name = "pm8350c_l1_ao";\n\t\t\t\t\tqcom,set = <0x1>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1b7740>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;', 'regulator-pm8350c-l1-ao {\n\t\t\t\t\tregulator-name = "pm8350c_l1_ao";\n\t\t\t\t\tqcom,set = <0x1>;\n\t\t\t\t\tregulator-min-microvolt = <0xf4240>;\n\t\t\t\t\tregulator-max-microvolt = <0xf4240>;\n\t\t\t\t\tqcom,init-voltage = <0xf4240>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-pm8350c-l1-so {\n\t\t\t\t\tregulator-name = "pm8350c_l1_so";\n\t\t\t\t\tqcom,set = <0x2>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1b7740>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;', 'regulator-pm8350c-l1-so {\n\t\t\t\t\tregulator-name = "pm8350c_l1_so";\n\t\t\t\t\tqcom,set = <0x2>;\n\t\t\t\t\tregulator-min-microvolt = <0xf4240>;\n\t\t\t\t\tregulator-max-microvolt = <0xf4240>;\n\t\t\t\t\tqcom,init-voltage = <0xf4240>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc2

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc2";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l2 {\n\t\t\t\t\tregulator-name = "pm8350c_l2";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1b7740>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;\n', '\t\t\t\tqcom,resource-name = "ldoc2";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l2 {\n\t\t\t\t\tregulator-name = "pm8350c_l2";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xf4240>;\n\t\t\t\t\tregulator-max-microvolt = <0xf4240>;\n\t\t\t\t\tqcom,init-voltage = <0xf4240>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc4

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc4";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l4 {\n\t\t\t\t\tregulator-name = "pm8350c_l4";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1a0040>;\n\t\t\t\t\tregulator-max-microvolt = <0x2dc6c0>;\n\t\t\t\t\tqcom,init-voltage = <0x1b9680>;\n', '\t\t\t\tqcom,resource-name = "ldoc4";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l4 {\n\t\t\t\t\tregulator-name = "pm8350c_l4";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1a0040>;\n\t\t\t\t\tregulator-max-microvolt = <0x1bc560>;\n\t\t\t\t\tqcom,init-voltage = <0x1b9680>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc5

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc5";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l5 {\n\t\t\t\t\tregulator-name = "pm8350c_l5";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1a0040>;\n\t\t\t\t\tregulator-max-microvolt = <0x2dc6c0>;\n\t\t\t\t\tqcom,init-voltage = <0x1b9680>;\n', '\t\t\t\tqcom,resource-name = "ldoc5";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l5 {\n\t\t\t\t\tregulator-name = "pm8350c_l5";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1a0040>;\n\t\t\t\t\tregulator-max-microvolt = <0x1bc560>;\n\t\t\t\t\tqcom,init-voltage = <0x1b9680>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc6

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc6";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\t\t\t\tproxy-supply = <0x24>;\n\n\t\t\t\tregulator-pm8350c-l6 {\n\t\t\t\t\tregulator-name = "pm8350c_l6";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x2d2a80>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;\n', '\t\t\t\tqcom,resource-name = "ldoc6";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\t\t\t\tproxy-supply = <0x24>;\n\n\t\t\t\tregulator-pm8350c-l6 {\n\t\t\t\t\tregulator-name = "pm8350c_l6";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1bc560>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc8

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc8";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l8 {\n\t\t\t\t\tregulator-name = "pm8350c_l8";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1b7740>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;\n', '\t\t\t\tqcom,resource-name = "ldoc8";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l8 {\n\t\t\t\t\tregulator-name = "pm8350c_l8";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xf4240>;\n\t\t\t\t\tregulator-max-microvolt = <0xf4240>;\n\t\t\t\t\tqcom,init-voltage = <0xf4240>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc10 no touch

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc10";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pm8350c-l10 {\n\t\t\t\t\tregulator-name = "pm8350c_l10";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124f80>;\n\t\t\t\t\tregulator-max-microvolt = <0x124f80>;\n\t\t\t\t\tqcom,init-voltage = <0x124f80>;\n', '\t\t\t\tqcom,resource-name = "ldoc10";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pm8350c-l10 {\n\t\t\t\t\tregulator-name = "pm8350c_l10";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xaae60>;\n\t\t\t\t\tregulator-max-microvolt = <0xaae60>;\n\t\t\t\t\tqcom,init-voltage = <0xaae60>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc11 no touch

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc11";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l11 {\n\t\t\t\t\tregulator-name = "pm8350c_l11";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x249f00>;\n\t\t\t\t\tregulator-max-microvolt = <0x2de600>;\n\t\t\t\t\tqcom,init-voltage = <0x263540>;\n', '\t\t\t\tqcom,resource-name = "ldoc11";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350c-l11 {\n\t\t\t\t\tregulator-name = "pm8350c_l11";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x249f00>;\n\t\t\t\t\tregulator-max-microvolt = <0x2dbef0>;\n\t\t\t\t\tqcom,init-voltage = <0x263540>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#ldoc12

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc12";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\t\t\t\tproxy-supply = <0x26>;\n\n\t\t\t\tregulator-pm8350c-l12 {\n\t\t\t\t\tregulator-name = "pm8350c_l12";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1e8480>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;\n', '\t\t\t\tqcom,resource-name = "ldoc12";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\t\t\t\tproxy-supply = <0x26>;\n\n\t\t\t\tregulator-pm8350c-l12 {\n\t\t\t\t\tregulator-name = "pm8350c_l12";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b7740>;\n\t\t\t\t\tregulator-max-microvolt = <0x1b7740>;\n\t\t\t\t\tqcom,init-voltage = <0x1b7740>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldoc13 no touch!!!!!

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoc13";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\t\t\t\tproxy-supply = <0x27>;\n\n\t\t\t\tregulator-pm8350c-l13 {\n\t\t\t\t\tregulator-name = "pm8350c_l13";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x2dc6c0>;\n\t\t\t\t\tregulator-max-microvolt = <0x2dc6c0>;\n\t\t\t\t\tqcom,init-voltage = <0x2dc6c0>;\n', '\t\t\t\tqcom,resource-name = "ldoc13";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\t\t\t\tproxy-supply = <0x27>;\n\n\t\t\t\tregulator-pm8350c-l13 {\n\t\t\t\t\tregulator-name = "pm8350c_l13";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x2dc2d8>;\n\t\t\t\t\tregulator-max-microvolt = <0x2dc2d8>;\n\t\t\t\t\tqcom,init-voltage = <0x2dc2d8>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#bobc1

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "bobc1";\n\n\t\t\t\tregulator-pm8350c-bob {\n\t\t\t\t\tregulator-name = "pm8350c_bob";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x2de600>;\n\t\t\t\t\tregulator-max-microvolt = <0x3c6cc0>;\n\t\t\t\t\tqcom,init-voltage = <0x2de600>;\n', '\t\t\t\tqcom,resource-name = "bobc1";\n\n\t\t\t\tregulator-pm8350c-bob {\n\t\t\t\t\tregulator-name = "pm8350c_bob";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x2de600>;\n\t\t\t\t\tregulator-max-microvolt = <0x3567e0>;\n\t\t\t\t\tqcom,init-voltage = <0x2de600>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldod1

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldod1";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pm8350b-l1 {\n\t\t\t\t\tregulator-name = "pm8350b_l1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x107ac0>;\n\t\t\t\t\tregulator-max-microvolt = <0x12ad40>;\n\t\t\t\t\tqcom,init-voltage = <0x124f80>;\n', '\t\t\t\tqcom,resource-name = "ldod1";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pm8350b-l1 {\n\t\t\t\t\tregulator-name = "pm8350b_l1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x107ac0>;\n\t\t\t\t\tregulator-max-microvolt = <0x126308>;\n\t\t\t\t\tqcom,init-voltage = <0x124f80>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#smpe1

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "smpe1";\n\n\t\t\t\tregulator-pmr735a-s1 {\n\t\t\t\t\tregulator-name = "pmr735a_s1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124f80>;\n\t\t\t\t\tregulator-max-microvolt = <0x138800>;\n\t\t\t\t\tqcom,init-voltage = <0x132a40>;\n', '\t\t\t\tqcom,resource-name = "smpe1";\n\n\t\t\t\tregulator-pmr735a-s1 {\n\t\t\t\t\tregulator-name = "pmr735a_s1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124f80>;\n\t\t\t\t\tregulator-max-microvolt = <0x138418>;\n\t\t\t\t\tqcom,init-voltage = <0x132a40>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#smpe2

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "smpe2";\n\n\t\t\t\tregulator-pmr735a-s2 {\n\t\t\t\t\tregulator-name = "pmr735a_s2";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x7a120>;\n\t\t\t\t\tregulator-max-microvolt = <0xf9060>;\n\t\t\t\t\tqcom,init-voltage = <0xd0020>;\n', '\t\t\t\tqcom,resource-name = "smpe2";\n\n\t\t\t\tregulator-pmr735a-s2 {\n\t\t\t\t\tregulator-name = "pmr735a_s2";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x7a120>;\n\t\t\t\t\tregulator-max-microvolt = <0xf8c78>;\n\t\t\t\t\tqcom,init-voltage = <0xd0020>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#smpe3

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "smpe3";\n\n\t\t\t\tregulator-pmr735a-s3 {\n\t\t\t\t\tregulator-name = "pmr735a_s3";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x2191c0>;\n\t\t\t\t\tregulator-max-microvolt = <0x23e380>;\n\t\t\t\t\tqcom,init-voltage = <0x2191c0>;\n', '\t\t\t\tqcom,resource-name = "smpe3";\n\n\t\t\t\tregulator-pmr735a-s3 {\n\t\t\t\t\tregulator-name = "pmr735a_s3";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x2191c0>;\n\t\t\t\t\tregulator-max-microvolt = <0x23df98>;\n\t\t\t\t\tqcom,init-voltage = <0x2191c0>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#ldoe1

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoe1";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l1 {\n\t\t\t\t\tregulator-name = "pmr735a_l1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xdea80>;\n\t\t\t\t\tregulator-max-microvolt = <0xdea80>;\n\t\t\t\t\tqcom,init-voltage = <0xdea80>;\n', '\t\t\t\tqcom,resource-name = "ldoe1";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l1 {\n\t\t\t\t\tregulator-name = "pmr735a_l1";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xde698>;\n\t\t\t\t\tregulator-max-microvolt = <0xde698>;\n\t\t\t\t\tqcom,init-voltage = <0xde698>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#ldoe2

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoe2";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l2 {\n\t\t\t\t\tregulator-name = "pmr735a_l2";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124f80>;\n\t\t\t\t\tregulator-max-microvolt = <0x124f80>;\n\t\t\t\t\tqcom,init-voltage = <0x124f80>;\n', '\t\t\t\tqcom,resource-name = "ldoe2";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l2 {\n\t\t\t\t\tregulator-name = "pmr735a_l2";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124b98>;\n\t\t\t\t\tregulator-max-microvolt = <0x124b98>;\n\t\t\t\t\tqcom,init-voltage = <0x124b98>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#ldoe3

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoe3";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l3 {\n\t\t\t\t\tregulator-name = "pmr735a_l3";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124f80>;\n\t\t\t\t\tregulator-max-microvolt = <0x124f80>;\n\t\t\t\t\tqcom,init-voltage = <0x124f80>;\n', '\t\t\t\tqcom,resource-name = "ldoe3";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l3 {\n\t\t\t\t\tregulator-name = "pmr735a_l3";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124b98>;\n\t\t\t\t\tregulator-max-microvolt = <0x124b98>;\n\t\t\t\t\tqcom,init-voltage = <0x124b98>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#ldoe4

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoe4";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pmr735a-l4 {\n\t\t\t\t\tregulator-name = "pmr735a_l4";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b1980>;\n\t\t\t\t\tregulator-max-microvolt = <0x1c9080>;\n\t\t\t\t\tqcom,init-voltage = <0x1b1980>;\n', '\t\t\t\tqcom,resource-name = "ldoe4";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pmr735a-l4 {\n\t\t\t\t\tregulator-name = "pmr735a_l4";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x1b1980>;\n\t\t\t\t\tregulator-max-microvolt = <0x1c8c98>;\n\t\t\t\t\tqcom,init-voltage = <0x1b1980>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#ldoe5

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoe5";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l5 {\n\t\t\t\t\tregulator-name = "pmr735a_l5";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xc3500>;\n\t\t\t\t\tregulator-max-microvolt = <0xc3500>;\n\t\t\t\t\tqcom,init-voltage = <0xc3500>;\n', '\t\t\t\tqcom,resource-name = "ldoe5";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l5 {\n\t\t\t\t\tregulator-name = "pmr735a_l5";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xc3118>;\n\t\t\t\t\tregulator-max-microvolt = <0xc3118>;\n\t\t\t\t\tqcom,init-voltage = <0xc3118>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#ldoe6

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoe6";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l6 {\n\t\t\t\t\tregulator-name = "pmr735a_l6";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x75300>;\n\t\t\t\t\tregulator-max-microvolt = <0xdcb40>;\n\t\t\t\t\tqcom,init-voltage = <0xc3500>;\n', '\t\t\t\tqcom,resource-name = "ldoe6";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\n\t\t\t\tregulator-pmr735a-l6 {\n\t\t\t\t\tregulator-name = "pmr735a_l6";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x75300>;\n\t\t\t\t\tregulator-max-microvolt = <0xdc758>;\n\t\t\t\t\tqcom,init-voltage = <0xc3500>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

#ldoe7

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
 # old_data = f.read()

#new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldoe7";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pmr735a-l7 {\n\t\t\t\t\tregulator-name = "pmr735a_l7";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x2ab980>;\n\t\t\t\t\tregulator-max-microvolt = <0x2ab980>;\n\t\t\t\t\tqcom,init-voltage = <0x2ab980>;\n', '\t\t\t\tqcom,resource-name = "ldoe7";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pmr735a-l7 {\n\t\t\t\t\tregulator-name = "pmr735a_l7";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x2ab598>;\n\t\t\t\t\tregulator-max-microvolt = <0x2ab598>;\n\t\t\t\t\tqcom,init-voltage = <0x2ab598>;\n')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
 # f.write(new_data)

###  LMXLVL

#ldob5

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-pm8350-l5 {\n\t\t\t\t\tregulator-name = "pm8350_l5";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xd6d80>;\n\t\t\t\t\tregulator-max-microvolt = <0xd8cc0>;\n\t\t\t\t\tqcom,init-voltage = <0xd6d80>;', 'regulator-pm8350-l5 {\n\t\t\t\t\tregulator-name = "pm8350_l5";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0xd6d80>;\n\t\t\t\t\tregulator-max-microvolt = <0xd6d80>;\n\t\t\t\t\tqcom,init-voltage = <0xd6d80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-pm8350-l5-ao {\n\t\t\t\t\tregulator-name = "pm8350_l5_ao";\n\t\t\t\t\tqcom,set = <0x1>;\n\t\t\t\t\tregulator-min-microvolt = <0xd6d80>;\n\t\t\t\t\tregulator-max-microvolt = <0xd6d80>;\n\t\t\t\t\tqcom,init-voltage = <0xd6d80>;', 'regulator-pm8350-l5-ao {\n\t\t\t\t\tregulator-name = "pm8350_l5_ao";\n\t\t\t\t\tqcom,set = <0x1>;\n\t\t\t\t\tregulator-min-microvolt = <0xd6d80>;\n\t\t\t\t\tregulator-max-microvolt = <0xd6d80>;\n\t\t\t\t\tqcom,init-voltage = <0xd6d80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-pm8350-l5-so {\n\t\t\t\t\tregulator-name = "pm8350_l5_so";\n\t\t\t\t\tqcom,set = <0x2>;\n\t\t\t\t\tregulator-min-microvolt = <0xd6d80>;\n\t\t\t\t\tregulator-max-microvolt = <0xd6d80>;\n\t\t\t\t\tqcom,init-voltage = <0xd6d80>;', 'regulator-pm8350-l5-so {\n\t\t\t\t\tregulator-name = "pm8350_l5_so";\n\t\t\t\t\tqcom,set = <0x2>;\n\t\t\t\t\tregulator-min-microvolt = <0xd6d80>;\n\t\t\t\t\tregulator-max-microvolt = <0xd6d80>;\n\t\t\t\t\tqcom,init-voltage = <0xd6d80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldob6

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldob6";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\t\t\t\tproxy-supply = <0x1e>;\n\n\t\t\t\tregulator-pm8350-l6 {\n\t\t\t\t\tregulator-name = "pm8350_l6";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124f80>;\n\t\t\t\t\tregulator-max-microvolt = <0x126ec0>;\n\t\t\t\t\tqcom,init-voltage = <0x124f80>;\n', '\t\t\t\tqcom,resource-name = "ldob6";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x7530>;\n\t\t\t\tproxy-supply = <0x1e>;\n\n\t\t\t\tregulator-pm8350-l6 {\n\t\t\t\t\tregulator-name = "pm8350_l6";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x124f80>;\n\t\t\t\t\tregulator-max-microvolt = <0x124f80>;\n\t\t\t\t\tqcom,init-voltage = <0x124f80>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

#ldob7

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('\t\t\t\tqcom,resource-name = "ldob7";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350-l7 {\n\t\t\t\t\tregulator-name = "pm8350_l7";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x249f00>;\n\t\t\t\t\tregulator-max-microvolt = <0x2de600>;\n\t\t\t\t\tqcom,init-voltage = <0x263540>;\n', '\t\t\t\tqcom,resource-name = "ldob7";\n\t\t\t\tqcom,regulator-type = "pmic5-ldo";\n\t\t\t\tqcom,supported-modes = <0x2 0x4>;\n\t\t\t\tqcom,mode-threshold-currents = <0x0 0x2710>;\n\n\t\t\t\tregulator-pm8350-l7 {\n\t\t\t\t\tregulator-name = "pm8350_l7";\n\t\t\t\t\tqcom,set = <0x3>;\n\t\t\t\t\tregulator-min-microvolt = <0x249f00>;\n\t\t\t\t\tregulator-max-microvolt = <0x2673c0>;\n\t\t\t\t\tqcom,init-voltage = <0x263540>;\n')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)



with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x2de600>;', 'qcom,init-voltage = <0x2dc6c0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,init-voltage = <0x2d2a80>;', 'qcom,init-voltage = <0x2d0370>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-min-microvolt = <0x2d2a80>;', 'regulator-min-microvolt = <0x2d0370>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-min-microvolt = <0x2de600>;', 'regulator-min-microvolt = <0x2dc6c0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-max-microvolt = <0xd8cc0>;', 'regulator-max-microvolt = <0xd6d80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-max-microvolt = <0x126ec0>;', 'regulator-max-microvolt = <0x124f80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('regulator-max-microvolt = <0x2de600>;', 'regulator-max-microvolt = <0x2dc6c0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)