#!/data/adb/888/dtb/bin/python3


#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  #old_data = f.read()

#new_data = old_data.replace('qcom,initial-pwrlevel = <0x9>;', 'qcom,initial-pwrlevel = <0xa>;')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  #f.write(new_data)
#qcom0
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x32116200>;', 'qcom,gpu-freq = <0x32a9f880>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0x1a0>;', 'qcom,level = <0x1a0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom1
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x2e5f5680>;', 'qcom,gpu-freq = <0x30e03500>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0x180>;', 'qcom,level = <0x180>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom2
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x2bfcfc80>;', 'qcom,gpu-freq = <0x2faf0800>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0x140>;', 'qcom,level = <0x150>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom3
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x284af100>;', 'qcom,gpu-freq = <0x2e5f5680>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0x100>;', 'qcom,level = <0x100>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom4
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = "$=X";', 'qcom,gpu-freq = <0x2bfcfc80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0xe0>;', 'qcom,level = <0xe0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom5
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x202fbf00>;', 'qcom,gpu-freq = <0x284af100>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0xc0>;', 'qcom,level = <0xc0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom6
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x1d4410c0>;', 'qcom,gpu-freq = "$=X";')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0x90>;', 'qcom,level = <0x90>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom7
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x1a67a4c0>;', 'qcom,gpu-freq = <0x202fbf00>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0x80>;', 'qcom,level = <0x80>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom8
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x169714c0>;', 'qcom,gpu-freq = <0x169714c0>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0x50>;', 'qcom,level = <0x50>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom9
with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,gpu-freq = <0x12c684c0>;', 'qcom,gpu-freq = <0x8f0d180>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  old_data = f.read()

new_data = old_data.replace('qcom,level = <0x40>;', 'qcom,level = <0x38>;')

with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  f.write(new_data)
#qcom10
#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  #old_data = f.read()

#new_data = old_data.replace('qcom,acd-level = <0x882f5ffd>;', 'qcom,acd-level = <0x882f5ffd>; \n                                        }; \n\n                                        qcom,gpu-pwrlevel@10 { \n                                                reg = <0xa>; \n                                                qcom,gpu-freq = <0x8f0d180>; \n                                                qcom,level = <0x38>; \n                                                qcom,bus-freq-ddr7 = <0x2>; \n                                                qcom,bus-min-ddr7 = <0x2>; \n                                                qcom,bus-max-ddr7 = <0x9>; \n                                                qcom,bus-freq-ddr8 = <0x2>; \n                                                qcom,bus-min-ddr8 = <0x2>; \n                                                qcom,bus-max-ddr8 = <0x7>; \n                                                qcom,acd-level = <0x882f5ffd>;')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  #f.write(new_data)

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  #old_data = f.read()

#new_data = old_data.replace('                                        qcom,gpu-pwrlevel@10 { \n                                                reg = <0xa>; \n                                                qcom,gpu-freq = <0x12c684c0>; \n                                                qcom,level = <0x40>; \n                                                qcom,bus-freq-ddr7 = <0x2>; \n                                                qcom,bus-min-ddr7 = <0x2>; \n                                                qcom,bus-max-ddr7 = <0x9>; \n                                                qcom,bus-freq-ddr8 = <0x2>; \n                                                qcom,bus-min-ddr8 = <0x2>; \n                                                qcom,bus-max-ddr8 = <0x7>; \n                                                qcom,acd-level = <0x882f5ffd>;', '-')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  #f.write(new_data)

    #with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'r') as f:
  #old_data = f.read()

#new_data = old_data.replace('0x180', '0x190')

#with open ('01_dtbdump_Qualcomm_Technologies,_Inc._Lahaina_V2.1_SoC.dts', 'w') as f:
  #f.write(new_data)                          
