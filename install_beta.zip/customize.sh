set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive /data/adb/888 0 0 0755 0644

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh


