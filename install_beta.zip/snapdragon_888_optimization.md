### snapdragon_888_optimization v3.4 - 04.08.2022

* General / EN
  * Fixed the design/text of the module
* General / RU
  * Исправлено оформление/текст модуля