### snapdragon_888_optimization v3.4 beta - 07.08.2022

* General / EN
  * Added code to work on older systems
  * Added several options for GPU undervolting
* General / RU
  * Добавлен код для работы на старых системах
  * Добавлено несколько вариантов андервольтинга GPU