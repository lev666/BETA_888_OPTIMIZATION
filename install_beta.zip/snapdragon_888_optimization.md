### snapdragon_888_optimization v3.4 - 04.08.2022

* General
  * Added support for CPU undervolting (questionable about stability)
  